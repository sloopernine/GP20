# Unity color picker

This is a simple color picker tool that looks like the one in unity editor, but can be used in built applications. It’s a part of unity UI system, so it works everywhere where normal UI would work, from mobile to VR. Thanks to a shader that draws the whole thing, color picker uses only one gameobject and doesn’t require a complex setup. Also thanks to this shader no textures are required, and lines are smooth at any resolution and size.

![Screenshot](Screenshot.png?raw=true)